# TechFest 2025 Website
This is a simple static website for TechFest 2025.

## How to Use
Open `index.html` in a browser to view the site.